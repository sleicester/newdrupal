
OUApp.Helpers.getMQ = function () {
    return window.getComputedStyle(document.body,':after').getPropertyValue('content');
}
